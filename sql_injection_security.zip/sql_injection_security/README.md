# Detecting Data Leaks Using SQL Injection
### Cloud Computing Task 2 • Cybersecurity Project

A clean, beginner-friendly Python Flask and SQLite project demonstrating how to detect, prevent, and log SQL Injection attacks to safeguard sensitive cloud database information.

## Quick Start
1. `python -m venv venv`
2. Windows: `venv\Scripts\activate` | Mac/Linux: `source venv/bin/activate`
3. `pip install -r requirements.txt`
4. `python app.py`
5. Open http://127.0.0.1:5000 (admin / admin123)
