document.addEventListener('DOMContentLoaded', () => {
    const togglePasswordBtn = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');

    if (togglePasswordBtn && passwordInput && eyeIcon) {
        togglePasswordBtn.addEventListener('click', () => {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            eyeIcon.classList.toggle('bi-eye', !isPassword);
            eyeIcon.classList.toggle('bi-eye-slash', isPassword);
        });
    }

    const fillDemoBtn = document.getElementById('fillDemoBtn');
    const usernameInput = document.getElementById('username');
    if (fillDemoBtn && usernameInput && passwordInput) {
        fillDemoBtn.addEventListener('click', () => {
            usernameInput.value = 'admin';
            passwordInput.value = 'admin123';
        });
    }
});
