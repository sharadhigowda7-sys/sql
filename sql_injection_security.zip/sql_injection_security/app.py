from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import re
import os
from datetime import datetime

app = Flask(__name__)
# Secret key for signing session cookies
app.secret_key = 'cloud-computing-task2-secret-key-change-in-production'

DATABASE = 'database.db'

# Suspicious SQL injection patterns to detect and block safely
SQLI_PATTERNS = [
    r"'\s*OR\s*'?1'?\s*=\s*'?1'?",      # ' OR '1'='1 or ' OR 1=1
    r"'\s*OR\s*''\s*=\s*''",            # ' OR ''=''
    r"\bUNION\s+SELECT\b",              # UNION SELECT
    r"\bDROP\s+TABLE\b",                # DROP TABLE
    r"--",                              # SQL line comment
    r"/\*",                             # SQL multiline comment start
    r"\*/",                             # SQL multiline comment end
    r"\bINSERT\s+INTO\b",               # Dangerous INSERT
    r"\bDELETE\s+FROM\b",               # Dangerous DELETE
    r"\bSELECT\s+.*\s+FROM\b",          # Embedded SELECT queries
]

def get_db_connection():
    """Create a database connection with dictionary-like row access."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database tables and insert the default demo admin user."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Table 1: users (stores user credentials with hashed passwords)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    ''')

    # Table 2: security_logs (stores security events and status)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS security_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT NOT NULL,
            status TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Create default demo user: admin / admin123 (hashed with Werkzeug)
    cursor.execute('SELECT id FROM users WHERE username = ?', ('admin',))
    admin_user = cursor.fetchone()
    if not admin_user:
        hashed_password = generate_password_hash('admin123')
        cursor.execute(
            'INSERT INTO users (username, password_hash) VALUES (?, ?)',
            ('admin', hashed_password)
        )
        # Log system initialization
        cursor.execute(
            'INSERT INTO security_logs (event, status, timestamp) VALUES (?, ?, ?)',
            ('System initialized: Default demo user created', 'Allowed', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        )

    conn.commit()
    conn.close()

def log_security_event(event_description, status):
    """Safely log an authentication or security event into the database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # Always use parameterized queries for inserting logs
        cursor.execute(
            'INSERT INTO security_logs (event, status, timestamp) VALUES (?, ?, ?)',
            (event_description, status, current_time)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error logging security event: {e}")

def detect_sql_injection(input_text):
    """
    Check if the input string contains known SQL injection signatures.
    Returns: (is_suspicious: bool, matched_pattern: str)
    """
    if not input_text:
        return False, None

    for pattern in SQLI_PATTERNS:
        match = re.search(pattern, input_text, re.IGNORECASE)
        if match:
            return True, match.group(0)
    
    return False, None

# Helper to prevent browser caching of protected pages
def prevent_caching(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# ----------------- ROUTES ----------------- #

@app.route('/')
def home():
    """Landing page: Redirect to dashboard if logged in, else render login page."""
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login with SQL injection detection and parameterized query protection."""
    if request.method == 'GET':
        if 'username' in session:
            return redirect(url_for('dashboard'))
        return render_template('login.html')

    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()

    # Step 1: Detect SQL injection signatures in both username and password fields
    is_sqli_user, user_pattern = detect_sql_injection(username)
    is_sqli_pass, pass_pattern = detect_sql_injection(password)

    if is_sqli_user or is_sqli_pass:
        detected_part = user_pattern if is_sqli_user else pass_pattern
        # Safe logging: Never log the raw password!
        log_security_event(f"Suspicious SQL injection attempt detected in input: '{detected_part}'", "Blocked")
        
        flash("Suspicious SQL Injection Attempt Detected and Blocked.", "danger")
        return render_template('login.html', previous_username=username), 400

    # Step 2: Input validation (ensure fields are not blank)
    if not username or not password:
        flash("Please enter both username and password.", "warning")
        return render_template('login.html', previous_username=username)

    # Step 3: Secure database lookup using PARAMETERIZED SQL QUERIES (prevents SQL injection)
    conn = get_db_connection()
    cursor = conn.cursor()
    # The '?' placeholder instructs SQLite to treat the input purely as a value, never executable SQL!
    cursor.execute('SELECT id, username, password_hash FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()

    # Step 4: Verify password hash using Werkzeug
    if user and check_password_hash(user['password_hash'], password):
        # Successful login
        session['user_id'] = user['id']
        session['username'] = user['username']
        log_security_event(f"Normal login by user '{username}'", "Allowed")
        flash(f"Welcome back, {username}!", "success")
        return redirect(url_for('dashboard'))
    else:
        # Invalid credentials (wrong password or user does not exist)
        log_security_event(f"Failed login attempt for username '{username}'", "Blocked")
        flash("Invalid username or password.", "danger")
        return render_template('login.html', previous_username=username)

@app.route('/dashboard')
def dashboard():
    """Protected dashboard: accessible only with an active session."""
    if 'username' not in session:
        flash("Please log in to access the dashboard.", "warning")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor()

    # Query statistics for dashboard metrics
    cursor.execute("SELECT COUNT(*) AS total FROM security_logs WHERE event NOT LIKE 'System initialized%'")
    total_attempts = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) AS blocked FROM security_logs WHERE status = 'Blocked'")
    blocked_attempts = cursor.fetchone()['blocked']

    cursor.execute("SELECT COUNT(*) AS allowed FROM security_logs WHERE status = 'Allowed' AND event NOT LIKE 'System initialized%'")
    successful_logins = cursor.fetchone()['allowed']

    # Fetch recent 5 logs for the quick table on dashboard
    cursor.execute("SELECT id, event, status, timestamp FROM security_logs ORDER BY id DESC LIMIT 5")
    recent_logs = cursor.fetchall()
    conn.close()

    response = make_response(render_template(
        'dashboard.html',
        username=session['username'],
        total_attempts=total_attempts,
        blocked_attempts=blocked_attempts,
        successful_logins=successful_logins,
        recent_logs=recent_logs
    ))
    return prevent_caching(response)

@app.route('/logs')
def logs():
    """Security Logs page: view full audit trail of allowed and blocked events."""
    if 'username' not in session:
        flash("Please log in to access the security logs.", "warning")
        return redirect(url_for('home'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, event, status, timestamp FROM security_logs ORDER BY id DESC")
    all_logs = cursor.fetchall()
    conn.close()

    response = make_response(render_template('logs.html', username=session['username'], logs=all_logs))
    return prevent_caching(response)

@app.route('/logout')
def logout():
    """Log out the user, clear session, and redirect to login."""
    session.clear()
    flash("You have been logged out successfully.", "info")
    response = make_response(redirect(url_for('home')))
    return prevent_caching(response)

if __name__ == '__main__':
    init_db()
    print("===============================================================")
    print(" SQL Injection Protection System Started Successfully!")
    print(" Running at: http://127.0.0.1:5000")
    print(" Demo credentials -> Username: admin | Password: admin123")
    print("===============================================================")
    app.run(debug=True, host='127.0.0.1', port=5000)
